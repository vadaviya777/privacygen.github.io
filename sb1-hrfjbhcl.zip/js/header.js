// Header functionality
document.addEventListener('DOMContentLoaded', () => {
  const header = document.getElementById('main-header');
  const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
  
  // Create mobile menu
  const mobileMenu = document.createElement('div');
  mobileMenu.className = 'mobile-menu';
  
  // Clone navigation items for mobile menu
  const mainNav = document.querySelector('.main-nav');
  const navList = mainNav.querySelector('ul').cloneNode(true);
  mobileMenu.appendChild(navList);
  document.body.appendChild(mobileMenu);
  
  // Toggle mobile menu
  mobileMenuToggle.addEventListener('click', () => {
    document.body.classList.toggle('mobile-menu-active');
    mobileMenu.classList.toggle('active');
    mobileMenuToggle.classList.toggle('active');
  });
  
  // Handle scroll behavior for header
  let lastScrollTop = 0;
  
  window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    if (scrollTop > 10) {
      header.style.boxShadow = 'var(--shadow-md)';
      header.style.backgroundColor = 'rgba(255, 255, 255, 0.98)';
    } else {
      header.style.boxShadow = 'var(--shadow)';
      header.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
    }
    
    lastScrollTop = scrollTop;
  });
  
  // Close mobile menu when clicking outside
  document.addEventListener('click', (e) => {
    if (
      mobileMenu.classList.contains('active') && 
      !mobileMenu.contains(e.target) && 
      !mobileMenuToggle.contains(e.target)
    ) {
      document.body.classList.remove('mobile-menu-active');
      mobileMenu.classList.remove('active');
      mobileMenuToggle.classList.remove('active');
    }
  });
  
  // Close mobile menu when window is resized to desktop
  window.addEventListener('resize', () => {
    if (window.innerWidth >= 768 && mobileMenu.classList.contains('active')) {
      document.body.classList.remove('mobile-menu-active');
      mobileMenu.classList.remove('active');
      mobileMenuToggle.classList.remove('active');
    }
  });
  
  // Add subtle hover animation to navigation items
  const navLinks = document.querySelectorAll('.main-nav a, .mobile-menu a');
  
  navLinks.forEach(link => {
    link.addEventListener('mouseenter', () => {
      link.style.transform = 'translateY(-2px)';
      link.style.transition = 'transform var(--transition-fast)';
    });
    
    link.addEventListener('mouseleave', () => {
      link.style.transform = 'translateY(0)';
    });
  });
});